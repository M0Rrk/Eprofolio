# Marc Barinsky
# 2021-06-07
# Choose your own adventutre game assisgment
# Main code starts line 31

############### IMPORTING MODULES/PACKAGES #####################
import time, sys
#import random

################# Game Functions ####################


def intro():
    print("Hi there\n")
    print("I'm Maru")
    print("The most popular cat on youtube")
    print("<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>")
    print(asciiCatWakeup)
    print("<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>")
    print("I'm hungry")
    print("What you do think about look for a Catnip")
    print("Meow, lets find the Catnip... I know it is somethere in the house")
    print("Don't give up lookin for it! it's somewhere out there")

    print("<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>")
    time.sleep(2)
    print("Let's think\n")
    time.sleep(2)

    #start game
    start()


def start():
    print(" where should we start from???\n")

    print(' Basement...')
    print("\n")
    print(' Second floor...')
    print("\n")
    print(' Kitchen...')
    print("\n")
    print("Where do you think catnip will be? ")
    livingRoom()


def option(optionNumber):
    choice = 0
    while choice < 1 or choice > optionNumber:
        print('1 to ' + str(optionNumber) + '> ', end='')
        choice = input()
        if choice != '1' and choice != '2' and choice != '3' and choice != '4' and choice != '5':
            print("You did not selected valid oprion")
            exitGame()
        if choice == '1' or choice == '2' or choice == '3' or choice == '4' or choice == '5':
            choice = int(choice)
    print('\n\n')
    return choice


#Game living room
def livingRoom():
    print(asciiCatLookingAround)
    levelOne = [
        "Kitchen", "Second floor", "Basement", "Take a nap",
        "Do not want to play"
    ]
    time.sleep(5)
    print('What will you do?')
    choiceNum = int(0)

    for i in levelOne:
        choiceNum += 1
        print(str(choiceNum) + " Go to " + i)

    choice = option(5)
    # jump to selected location
    if 1 == choice:
        print("hmm, my favorite place in the house ?")
        print('Where do you think I can find catnip?')
        print("You've looked around and have found the catnip has ran out ")
        kitchen()
    elif 2 == choice:
        secoundFloor()
    elif 3 == choice:
        print("Hmm, too dark here")
        basement()
    elif 4 == choice:
        takeANap()
    elif 5 == choice:
        exitGame()
    else:
        print("Error!")


#game Kitchen
def kitchen():
    print(asciiCatBasementStorage)

    levelOneKitchen = [
        "island", "door to backyard", "window next to dinning table",
        "Take a nap", "Do not want to play"
    ]
    time.sleep(5)
    print("Where it can be \n Where will you go?")
    choiceNum = int(0)

    for i in levelOneKitchen:
        choiceNum += 1
        print(str(choiceNum) + " Go to " + i)

    choice = option(5)
    # jump to selected location
    if 1 == choice: island()
    elif 2 == choice: doortoBackyard()
    elif 3 == choice: windowNextToDinningTable()
    elif 4 == choice: takeANap()
    elif 5 == choice: exitGame()
    else: print("Error!")


#take a nap function
def takeANap():
    print(asciiSleepingCat)
    time.sleep(5)
    livingRoom()


#Island function
def island():
    islandList = [
        "what is here?", "seems like Mom cleaned everything before she left",
        "let's go back"
    ]
    for i in islandList:
        print(i)
        time.sleep(3)
    kitchen()


#door to backyard function
def doortoBackyard():
    doortoBackyardList = [
        "what is weather today?", "if there is catnip it will be outside",
        "door is closed \n let's go back"
    ]
    for i in doortoBackyardList:
        print(i)
        time.sleep(3)
    kitchen()


#found catnip
def windowNextToDinningTable():
    print("WOW")
    time.sleep(5)
    print("I smell catnip")
    time.sleep(5)
    print(asciiHappyCat)
    time.sleep(2)
    print("Thank you :)")


#Basement definition
def basement():
    time.sleep(2)
    print(asciiCatInBasement)
    levelBasement = [
        "storage room", "coldroom", "Take a nap", "Do not want to play"
    ]
    time.sleep(5)
    print("Where do you think I can find catnip?\n Whrer should I go?")
    choiceNum = int(0)

    for i in levelBasement:
        choiceNum += 1
        print(str(choiceNum) + " Go to " + i)

    choice = option(4)
    # jump to selected location
    if 1 == choice:
        print(asciiCatBasementStorage)
        basementStorage()
    elif 2 == choice:
        coldroom()
        print("coldroom")
    elif 3 == choice:
        takeANap()
    elif 4 == choice:
        exitGame()
    else:
        print("Error!")


# Basement Storage definition and loop
def basementStorage():
    coldRoomList = [
        "what is all this stuff", "too manysuitcases",
        "do not smell any catnip here", "to cold for catnip \n let's go back"
    ]
    for i in coldRoomList:
        print(i)
        time.sleep(3)
    basement()


# Coldroom definition
def coldroom():
    coldRoomList = [
        "So cold brrrrrr", "What are all these cans",
        "do not smell any catnip here", "to cold for catnip \n let's go back"
    ]
    for i in coldRoomList:
        print(i)
        time.sleep(3)
    basement()


# Second floor definition
def secoundFloor():
    levelSecond = [
        "Kid room", " Mom room", "Bathroom", "Take a nap",
        "Do not want to play"
    ]

    print(
        "Where do you think I can find catnip on the second floor?\n Where should I go?"
    )
    choiceNum = int(0)

    for i in levelSecond:
        choiceNum += 1
        print(str(choiceNum) + " Go to " + i)

    choice = option(5)
    # jump to selected location
    print(asciiFloorCat)
    if 1 == choice:
        print("my favorite guy room is here")
        kidRoom()
    elif 2 == choice:
        momRoom()
    elif 3 == choice:
        bathRoom()
    elif 4 == choice:
        takeANap()
    elif 5 == choice:
        livingRoom()
    else:
        print("Error!")


# Kid room definition
def kidRoom():
    kidRoomList = [
        "WOW, new toys", "where can be catnip here",
        "do not smell any catnip here", "let's go away"
    ]

    for i in kidRoomList:
        print(i)
        time.sleep(3)
    secoundFloor()


# Mom room definition
def momRoom():
    momRoomList = [
        "Hmm, mom's room", "this room is too clean and empty",
        "do not smell any catnip here", "let's go back"
    ]
    for i in momRoomList:
        print(i)
        time.sleep(3)
    secoundFloor()


# Bathroom definition
def bathRoom():
    bathRoomList = [
        "Oh NOOOOO", "hate this place", "do not smell any catnip here",
        "let's go away"
    ]
    for i in bathRoomList:
        print(i)
        time.sleep(3)
    secoundFloor()


#exitGame definition
def exitGame():
    quitTheGame = input("Do you want to try again Y/N?")

    if (quitTheGame == "Y"):
        print("Great !Let's play again")
        intro()
    else:
        print("Thank you for stopping by")
        print("Come over again")
        exit(0)


###################### CAT ASCII ART ############################
# ascii art source --> https://textart.io/
asciiCatWakeup = r"""
        _,'|             _.-''``-...___..--';)
       /_ \'.      __..-' ,      ,--...--'''
      <\    .`--'''       `     /'
       `-';'               ;   ; ;
 __...--''     ___...--_..'  .;.'
(,__....----'''       (,..--''   
"""

asciiCatBasementStorage = r"""
              ,-.       _,---._ __  / \
             /  )    .-'       `./ /   \
            (  (   ,'            `/    /|
             \  `-"             \'\   / |
              `.              ,  \ \ /  |
               /`.          ,'-`----Y   |
              (            ;        |   '
              |  ,-.    ,-'         |  /
              |  | (   |            | /
              )  |  \  `.___________|/
              `--'   `--' """

# ascii art source --> https://textart.io/
asciiHappyCat = r"""


                 ,.     ,.
                {^ \-"-/ ^}
                "   """ """
               { <O> _ <O> }
               ==_ .:Y:. _==
             .""  `--^--' "".
            (,~-~."" "" ,~-~.)
      ------(     )----(     )-----
            ^-'-'-^    ^-'-'-^
      _____________________________
            |""" " /~.^.~\ " """|
             ,i-i-i(""(  i-i-i.
            (o o o ))"")( o o o)
             \(_) /(""(  \ (_)/
              `--'  \""\  `--'
                     )"")
                    (""/
                     `"
                     """ """"""

#ascii art source --> https://textart.io/
asciiCatInBasement = r"""

 /\_/\
( o.o )
 > ^ <
"""
#ascii art source --> https://textart.io/
asciiCatLookingAround = r"""
    /\__/\
   /`    '\
 === 0  0 ===
   \  --  /
  /        \
 /          \
|            |
 \  ||  ||  /
  \_oo__oo_/#######
"""
#ascii art source --> https://textart.io/
asciiSleepingCat = r"""
  |\      _,,,,--,,_
  /,`.-'`'    -,  \-;,
 |,4-  ) ),,__ ,\ (  ;;
'---''(.'--'  `-'`.)`'
"""
#ascii art source --> https://textart.io/
asciiFloorCat = r"""
       /\
    ,___/  |,
   / \       \,
 _/ 0\         \
'; =====        |
  \_             |
    \          /
     |         |
     /          \,
    /             \
   /
  |
  """
###################### THE MAIN GAME LOOP ############################
#------------------Game Loop ------------------------
#while True:
# Start the game
intro()

# End the game...
#snd.quitScript()
print("Quitting...")
exitGame()
