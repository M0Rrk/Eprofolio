//Marc Barinsky
// Mr.Naccarato
//10/1/2021
//ICS4U
//creates a slot machine using 3 images and a win or lose window
import javax.swing.JOptionPane;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.util.Random;
import java.util.ArrayList;

public class Main
{

	public static void main(String[] args) 
	{
		//Window

        JFrame jframe = new JFrame("Slot Machine");
        jframe.setSize(640, 480);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon iconBars = new ImageIcon("Bars.jpg");
        
        JButton buttonPlay = new JButton("Play");
        
        JLabel welcomeText  = new JLabel("Welcome to Slot Machine, please press Play button");
        
        JPanel jpanelInit = new JPanel();
        
        ArrayList<ImageIcon> images = new ArrayList<ImageIcon>(); 

        jpanelInit.add(welcomeText);
        jpanelInit.add(buttonPlay);

        JLabel label1 = new JLabel(iconBars);
		JLabel label2 = new JLabel(iconBars);
        JLabel label3 = new JLabel(iconBars); 

        JPanel jPanelPlay1 = new JPanel();
        JPanel jPanelPlay2 = new JPanel();
        JPanel jPanelPlay3 = new JPanel();
        jPanelPlay1.add(label1);
        jPanelPlay2.add(label2);
        jPanelPlay3.add(label3);

	    //JPanel pane = new JPanel();
        //pane.setLayout(new GridLayout(3, 3));
        jframe.setLayout(new BorderLayout());

        jframe.getContentPane().add(jpanelInit, BorderLayout.NORTH);
        jframe.getContentPane().add(jPanelPlay1, BorderLayout.EAST);
        jframe.getContentPane().add(jPanelPlay2, BorderLayout.CENTER);
        jframe.getContentPane().add(jPanelPlay3, BorderLayout.WEST);

        jframe.pack();

		jframe.setVisible(true);
  
		buttonPlay.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
                 
                images.add(new ImageIcon("Bars.jpg"));
                images.add(new ImageIcon("Cherry.jpg"));
                images.add(new ImageIcon("Sevens.jpg"));
                
                Random generator = new Random();
                
                               
                int slot1=generator.nextInt(images.size());
                int slot2=generator.nextInt(images.size());
                int slot3=generator.nextInt(images.size());
                int slot4=generator.nextInt(images.size());
                int slot5=generator.nextInt(images.size());
                int slot6=generator.nextInt(images.size());
                int slot7=generator.nextInt(images.size());
                int slot8=generator.nextInt(images.size());
                int slot9=generator.nextInt(images.size());


                //JPanel pane = new JPanel();
        //pane.setLayout(new GridLayout(3, 3));
       // JLable iconLabels = new JLable[OPTIONS.length];

        //for (int i = 0; i < buttons.length; i++) {
        //    buttons[i] = new JButton(OPTIONS[i]);
        //    pane.add(buttons[i]);
        //}

        //frame.add(new JLabel("Which is not an animal?"), //BorderLayout.NORTH);
       // frame.add(pane, BorderLayout.CENTER);
                JLabel labelPlay1 = new JLabel();
		        JLabel labelPlay2 = new JLabel();
                JLabel labelPlay3 = new JLabel();  

                labelPlay1.setIcon(images.get(slot1));
                labelPlay2.setIcon(images.get(slot2));
                labelPlay3.setIcon(images.get(slot3));

                JPanel jPanelPlay1 = new JPanel();
                JPanel jPanelPlay2 = new JPanel();
                JPanel jPanelPlay3 = new JPanel();

                jPanelPlay1.add(labelPlay1 );
                jPanelPlay2.add(labelPlay2);
                jPanelPlay3.add(labelPlay3);

                jframe.getContentPane().add(jPanelPlay1, BorderLayout.EAST);
                jframe.getContentPane().add(jPanelPlay2, BorderLayout.CENTER);
                jframe.getContentPane().add(jPanelPlay3, BorderLayout.WEST);
                jframe.setVisible(true);

                if(slot1 == slot2 && slot2 == slot3)
                {
                    String win = "You Win!";
                    JOptionPane.showMessageDialog(jframe, win);
                    
                   
                }
                else
                {
                    String lost = "You Lost!";
                    JOptionPane.showMessageDialog(jframe, lost);
     
                }

		        

			}
        });	
        
        
	}

}
