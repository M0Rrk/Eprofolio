package com.company;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class Music
{
    Clip clip;
    float previousVolume=0;
    float currentVolume=0;
    FloatControl fc;
    boolean playMusic=false;

    public void setFile(File file)
    {

        try {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            clip = AudioSystem.getClip();
            clip.open(audioStream);
            fc=(FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
        }
        catch (UnsupportedAudioFileException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (LineUnavailableException e)
        {
            e.printStackTrace();
        }
    }

    public void playMusic(File file)
    {
        clip.setFramePosition(0);
        clip.start();
    }
    public void stopMusic(File file)
    {
        clip.stop();
    }
    public void muteMusic()
    {
        if(playMusic==false)
        {
            System.out.print("mute");
            previousVolume=currentVolume;
            currentVolume=-80.0f;
            fc.setValue((currentVolume));
            playMusic=true;
        }
        else if (playMusic==true)
        {
            currentVolume=previousVolume;
            fc.setValue(currentVolume);
            playMusic=false;
        }
    }


}
