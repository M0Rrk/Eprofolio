package com.company;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.sound.sampled.*;
import javax.swing.*;

public class TicTacToe implements ActionListener
{

    Random random = new Random();
    JFrame frame = new JFrame();
    JPanel title_panel = new JPanel();
    JPanel button_panel = new JPanel();
    JLabel textfield = new JLabel();
    JButton[] buttons = new JButton[9];
    JPanel playerPanel = new JPanel();
    JLabel playerTextField = new JLabel();
    Icon musicIcon = new ImageIcon(".idea/sound.png");
    JButton musicButton = new JButton(musicIcon);
    boolean playMusic;
    boolean player1_turn;
    Music music = new Music();
    File file = new File("Fanfare60.wav");
    int count=0;

    TicTacToe()
    {

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,800);
        frame.getContentPane().setBackground(new Color(50,50,50));
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);

        //textfield.setBackground(new Color(0, 0, 0));
        textfield.setForeground(new Color(25,25,25));
        textfield.setFont(new Font("Arial",Font.BOLD,75));
        textfield.setHorizontalAlignment(JLabel.CENTER);
        textfield.setText("Tic-Tac-Toe");
        textfield.setOpaque(true);

        title_panel.setLayout(new BorderLayout());
        title_panel.setBounds(0,0,800,100);

        button_panel.setLayout(new GridLayout(3,3));
        button_panel.setBackground(new Color(150,150,150));

        //playerTextField.setBackground(new Color(25,25,25));
        playerTextField.setForeground(new Color(0, 0,0));
        playerTextField.setFont(new Font("Arial",Font.BOLD,75));
        playerTextField.setText("Turn: ");
        playerTextField.setOpaque(true);




        for(int i=0;i<9;i++)
        {
            buttons[i] = new JButton();
            button_panel.add(buttons[i]);
            buttons[i].setFont(new Font("Arial",Font.BOLD,120));
            buttons[i].setFocusable(false);
            buttons[i].addActionListener(this);
        }

        musicButton.setFocusable(false);
        musicButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                music.muteMusic();
            }


            });

        title_panel.add(textfield);
        frame.add(title_panel,BorderLayout.NORTH);
        frame.add(button_panel,BorderLayout.CENTER);
        playerPanel.add(playerTextField,BorderLayout.WEST);
        playerPanel.add(musicButton,BorderLayout.EAST);
        frame.add(playerPanel,BorderLayout.SOUTH);
        startMusic();

        firstTurn();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

        for(int i=0;i<9;i++)
        {
            if(e.getSource()==buttons[i])
            {
                count++;
                if(player1_turn)
                {
                    if(buttons[i].getText()=="")
                    {
                        buttons[i].setForeground(new Color(255,0,0));
                        buttons[i].setText("X");
                        player1_turn=false;
                        playerTextField.setText("0 turn");
                        check();
                    }
                }
                else
                {
                    if(buttons[i].getText()=="")
                    {
                        buttons[i].setForeground(new Color(0,0,255));
                        buttons[i].setText("O");
                        player1_turn=true;
                        playerTextField.setText("X turn");
                        check();
                    }
                }
            }
        }
    }

    public void startMusic ()
    {
            music.setFile(file);
            music.playMusic(file);
    }
    public void firstTurn()
    {

        try
        {
            Thread.sleep(2000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if(random.nextInt(2)==0)
        {
            player1_turn=true;
            playerTextField.setText("X turn");
        }
        else
        {
            player1_turn=false;
            playerTextField.setText("O turn");
        }
    }

    public void check()
    {
        //check X win conditions
        boolean draw = false;
        if
        ((buttons[0].getText()=="X") && (buttons[1].getText()=="X") && (buttons[2].getText()=="X"))
        {
            xWins(0,1,2);
            draw=true;
        }
        if
        ((buttons[3].getText()=="X") && (buttons[4].getText()=="X") && (buttons[5].getText()=="X"))
        {
            xWins(3,4,5);
            draw=true;
        }
        if
        ((buttons[6].getText()=="x") && (buttons[7].getText()=="X") && (buttons[8].getText()=="X"))
        {
            xWins(6,7,8);
            draw=true;
        }
        if((buttons[0].getText()=="X") && (buttons[3].getText()=="X") && (buttons[6].getText()=="X"))
        {
            xWins(0,3,6);
            draw=true;
        }
        if((buttons[1].getText()=="X") && (buttons[4].getText()=="X") && (buttons[7].getText()=="X"))
        {
            xWins(1,4,7);
            draw=true;
        }
        if((buttons[2].getText()=="X") && (buttons[5].getText()=="X") && (buttons[8].getText()=="X"))
        {
            xWins(2,5,8);
            draw=true;
        }
        if((buttons[0].getText()=="X") && (buttons[4].getText()=="X") && (buttons[8].getText()=="X"))
        {
            xWins(0,4,8);
            draw=true;
        }
        if((buttons[2].getText()=="X") && (buttons[4].getText()=="X") && (buttons[6].getText()=="X"))
        {
            xWins(2,4,6);
            draw=true;
        }
        //check O win conditions
        if((buttons[0].getText()=="O") && (buttons[1].getText()=="O") && (buttons[2].getText()=="O"))
        {
            oWins(0,1,2);
            draw=true;
        }
        if((buttons[3].getText()=="O") && (buttons[4].getText()=="O") && (buttons[5].getText()=="O"))
        {
            oWins(3,4,5);
            draw=true;
        }
        if((buttons[6].getText()=="O") && (buttons[7].getText()=="O") && (buttons[8].getText()=="O"))
        {
            oWins(6,7,8);
            draw=true;
        }
        if((buttons[0].getText()=="O") && (buttons[3].getText()=="O") && (buttons[6].getText()=="O"))
        {
            oWins(0,3,6);
            draw=true;
        }
        if((buttons[1].getText()=="O") && (buttons[4].getText()=="O") && (buttons[7].getText()=="O"))
        {
            oWins(1,4,7);
            draw=true;
        }
        if((buttons[2].getText()=="O") && (buttons[5].getText()=="O") && (buttons[8].getText()=="O"))
        {
            oWins(2,5,8);
            draw=true;
        }
        if((buttons[0].getText()=="O") && (buttons[4].getText()=="O") && (buttons[8].getText()=="O"))
        {
            oWins(0,4,8);
            draw=true;
        }
        if((buttons[2].getText()=="O") && (buttons[4].getText()=="O") && (buttons[6].getText()=="O"))
        {
            oWins(2,4,6);
            draw=true;
        }
        if(!draw&&count>8)
        {
            playerTextField.setText("Draw");
        }


    }

    public void xWins(int a,int b,int c)
    {
        buttons[a].setBackground(Color.GREEN);
        buttons[b].setBackground(Color.GREEN);
        buttons[c].setBackground(Color.GREEN);

        for(int i=0;i<9;i++)
        {
            buttons[i].setEnabled(false);
        }
        playerTextField.setText("X wins");
    }
    public void oWins(int a,int b,int c)
    {
        buttons[a].setBackground(Color.GREEN);
        buttons[b].setBackground(Color.GREEN);
        buttons[c].setBackground(Color.GREEN);

        for(int i=0;i<9;i++)
        {
            buttons[i].setEnabled(false);
        }
        playerTextField.setText("0 wins");
    }
    public void musicActionListener (boolean musicMode) throws UnsupportedAudioFileException, IOException, LineUnavailableException
    {
        File file = new File("Fanfare60.wav");
        AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
        Clip clip = AudioSystem.getClip();
        clip.open(audioStream);

        if(musicMode)
        {
            clip.start();
            musicMode=false;
        }
        else
        {
            clip.stop();
            musicMode=true;
        }
    }
}

