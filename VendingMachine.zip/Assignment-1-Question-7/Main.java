import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;

import java.util.ArrayList;
import javax.swing.JOptionPane;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 

public class SlotMachineGUI
{
	private static boolean output = false;

    public static void main(String[] args) throws FileNotFoundException 
	{
		//read file
        Scanner sc = new Scanner(new BufferedReader(new FileReader("C:\\WEB\\nm1\\v62_0\\SlotMachineGUI\\src\\drinks.txt")));
    	String str;
    	final ArrayList<String> names = new ArrayList<String>();   	
    	final ArrayList<Double> prices = new ArrayList<Double>();   	

    	// Assumes the file has two "words" per line
    	 while(sc.hasNext())
    	 {
    	    String name = sc.next();
    	    names.add(name);
    	    double number = Double.parseDouble(sc.next());
    	    prices.add(number);
    	  }
 
		//Window
    	final JFrame jframe = new JFrame("Vending Machine");
        jframe.setSize(640, 480);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel pane = new JPanel();
        final JButton[] buttons = new JButton [prices.size()];
       
     	for (int i=0;i<prices.size();i++)
    	  {
           buttons[i] = new JButton(names.get(i)+ "\n" + prices.get(i).toString());
           //add Action command
           String s=Integer.toString(i);
           buttons[i].setActionCommand(s);
           pane.add(buttons[i]);
       
    	  }
       
        jframe.getContentPane().add(pane, "North");
        
        JLabel textLabel = new JLabel("Enter Amount and press OK:");
        final JTextField amount = new JTextField (2);
        JButton buttonBuy = new JButton(" OK ");
        
        JPanel textPanel = new JPanel();
        textPanel.add(textLabel);
        textPanel.add(amount);
        textPanel.add(buttonBuy);
        jframe.getContentPane().add(textPanel, "Center");           
       
        // button action listener to check if amount is entered
        buttonBuy.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
                String inputAmount =amount.getText();
                if (!inputAmount.isEmpty())
                {	
                	String selectText = "Please select your drink";
                    JOptionPane.showMessageDialog(jframe, selectText);
                            	
                	for (int i = 0; i < buttons.length ; i++)
                 	{

                    //Add action listener to button
                		final JButton clickedButton =  buttons[i];
                		buttons[i].addActionListener(new ActionListener()
                		{
                			//clickedButton =  buttons[i];
                			public void actionPerformed(ActionEvent g)
                			{
                				//Execute when button is pressed
                				System.out.println("You clicked the button" + clickedButton.getActionCommand());
                				String buttonPressedName = clickedButton.getActionCommand();
                				String lastChar = buttonPressedName.substring(buttonPressedName.length()-1);
                				int clickedButton = Integer.parseInt(lastChar);
                				System.out.println("You clicked the button" + buttonPressedName + " last char: " + lastChar + " interger " + clickedButton);
               				
                				double change = 0.0;
                         	    double convertAmount = Double.parseDouble(amount.getText());	                				
	                			System.out.println("You have selected:" + names.get(clickedButton) + "  price: " + prices.get(clickedButton).toString());                				
	                			if(prices.get(clickedButton)<=convertAmount)
	                			{
	                				change = convertAmount-prices.get(clickedButton);             					
	                				JOptionPane.showMessageDialog(jframe, "Here is your product:" +names.get(clickedButton) + "\nHere is your change $" + String.format("%.2f",change));
	                				output = true;
	                			}
	                			else
	                			{	
	                				String enoughMoney = "You didn't put enough money";
	                				JOptionPane.showMessageDialog(jframe, enoughMoney);                              
	                			}

                			}//action performed
                		});//drinks button action listener
                		if(output)
                		{break;}
                    }//for           	 
                }         
                else
                {
                    String noMoney = "You didn't put any money";
                    JOptionPane.showMessageDialog(jframe, noMoney);
                }
            }
        });	
        
		jframe.setVisible(true);
        
    }
}


